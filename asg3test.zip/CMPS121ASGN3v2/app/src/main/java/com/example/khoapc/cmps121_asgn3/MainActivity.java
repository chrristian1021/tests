package com.example.khoapc.cmps121_asgn3;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager.WakeLock;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import java.util.concurrent.atomic.AtomicLong;
import de.greenrobot.event.EventBus;


public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = "MainActivity";

    private boolean serviceBound;
    private MyService myService;


    boolean moved = false;
    AtomicLong timeMoved = null;
    public long timeThresh = 30000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        serviceBound = false;

        //Intent intent = new Intent(this, MyService.class);
        //startService(intent);
        //bindMyService();
        onResume();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);



    }

    @Override
    protected void onStart() {
        super.onStart();


//        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
//
//        if (powerManager != null) {
//            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
//                    "MyWakelockTag");
//            wakeLock.acquire(10 * 60 * 1000L /*10 minutes*/);
//        }

    }



    @Override
    protected void onResume() {
        super.onResume();
        Intent intent = new Intent(this, MyService.class);
        startService(intent);
        bindMyService();

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        //Checks three things:
        //1. If the phone was moved
        //2. If it was moved more than 30 seconds ago
        //3. That timeMoved is set and not a null value
        //If it passes, the message that the device has moved will be posted
        //There is a slight delay in the posting of the message
        if(moved && timeMoved!=null && (System.currentTimeMillis() - timeMoved.get() > timeThresh)){
            TextView tv = (TextView) findViewById(R.id.number_view);
            tv.setText("THE DEVICE WAS MOVED");
        }


    }

    private void bindMyService() {
        Intent intent = new Intent(this, MyService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }


    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder serviceBinder) {
            MyService.MyBinder binder = (MyService.MyBinder) serviceBinder;
            myService = binder.getService();
            serviceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {

            serviceBound = false;
        }
    };


    @Override
    protected void onPause() {
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        super.onPause();
    }

    public void onEventMainThread(ServiceResult result) {
        Log.i(LOG_TAG, "Displaying: " + result.intValue);
        TextView tv = (TextView) findViewById(R.id.number_view);
        tv.setText(Integer.toString(result.intValue));
    }

    //Handles messages passed containing the time that the phone was moved
    public void onEventMainThread(AtomicLong moveTime) {
        //long now = System.currentTimeMillis();
        Log.i(LOG_TAG, "moved = " + moved);
        //Log.i(LOG_TAG, "time now = " + now);
        Log.i(LOG_TAG, "time moved = " + moveTime);
        moved = true;
        timeMoved = new AtomicLong(moveTime.get());

    }


    public void clickClear(View v){
        moved = false;
        timeMoved = null;
        myService.clearTask();
        TextView tv = (TextView) findViewById(R.id.number_view);
        tv.setText("Everything is Quiet");

    }

    //stops the service and unbinds from it, then exits the app
    public void clickExit(View v){
        //serviceBound = false;
        if(serviceBound)
            unbindService(serviceConnection);
        serviceBound = false;
        Log.i(LOG_TAG, "Stopping application.");
        Intent intent = new Intent(this, MyService.class);
        stopService(intent);
        Log.i(LOG_TAG, "Stopped application.");
        finish();
    }



}

//    public void handleState(MyServiceTask task, int state) {
//        Message completeMessage = mHandler.obtainMessage(state, task);
//        completeMessage.sendToTarget();
//
//    }
//
//    Handler mHandler = new Handler(Looper.getMainLooper()) {
//        @Override
//        public void handleMessage(Message inputMessage) {
//            // Gets the task from the incoming Message object.
//            MyService photoTask = (MyService) inputMessage.obj;
//            // Gets the ImageView for this task
//            boolean moved = photoTask.didItMove();
//
//        }
//
//    };


//    private class UiCallback implements Handler.Callback {
//        @Override
//        public boolean handleMessage(Message message) {
//            if (message.what == DISPLAY_NUMBER) {
//                // Gets the result.
//                ServiceResult result = (ServiceResult) message.obj;
//                // Displays it.
//                if (result != null) {
//                    TextView tv = findViewById(R.id.moved);
//                    tv.setText(result.toString());
//
//                    if (serviceBound && myService != null) {
//                        myService.releaseResult(result);
//                    }
//                } else {
//                    Log.e("", "Error: received empty message!");
//                }
//            }
//            return true;
//        }
//    }