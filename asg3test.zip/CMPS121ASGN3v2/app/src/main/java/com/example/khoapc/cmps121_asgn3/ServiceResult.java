package com.example.khoapc.cmps121_asgn3;

    public class ServiceResult {
        ServiceResult() {}

        public int intValue;
    }

